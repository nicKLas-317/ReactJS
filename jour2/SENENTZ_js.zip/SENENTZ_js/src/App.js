import './App.css';
import Inputcpn from './tp_villes_j2/Components/Inputdata';


function App() {
  return (
    <div className="App">
      <Inputcpn/>
    </div>
  );
}

export default App;
