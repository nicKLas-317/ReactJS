import React from 'react';
import './Footerbar.css'



// Composant function
// export function App2()
const Footerbar = () => {
    return (
        <div>
            <ul className="header">
                <li>1F</li>
                <li>2F</li>
                <li>3F</li>
            </ul>
        </div>
    )
}



export default Footerbar