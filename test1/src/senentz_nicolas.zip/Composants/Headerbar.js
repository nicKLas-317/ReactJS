import React from 'react';
import './Headerbar.css'



// Composant function
// export function App2()
const Headerbar = () => {
    return (
        <div>
            <ul className="header">
                <li>1H</li>
                <li>2H</li>
                <li>3H</li>
            </ul>
        </div>
    )
}



export default Headerbar